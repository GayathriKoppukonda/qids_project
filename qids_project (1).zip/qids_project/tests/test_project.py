import unittest
import numpy as np

from src.attacks import make_registry
from src.detector import ThreatDetector
from src.protocol import recover_bob_state
from src.quantum import STATE_VECTORS, projective_success_probability


class QIDSTests(unittest.TestCase):
    def setUp(self):
        self.registry, self.sec = make_registry()
        self.detector = ThreatDetector(self.registry, threshold=0.90, min_shots=30, z_value=3.0)
        self.rng = np.random.default_rng(123)

    def test_teleportation_recovers_state(self):
        packet = self.registry.issue("ALICE", "BOB", self.sec["ALICE"], self.sec["BOB"], "M", "Y+")
        bob = recover_bob_state(packet, rng=self.rng)
        self.assertAlmostEqual(projective_success_probability(bob, "Y+"), 1.0, places=9)

    def test_legitimate_is_accepted(self):
        packet = self.registry.issue("ALICE", "BOB", self.sec["ALICE"], self.sec["BOB"], "M", "X+")
        bob = recover_bob_state(packet, rng=self.rng)
        result = self.detector.verify(packet, self.sec["BOB"], bob, shots=200)
        self.assertEqual(result.decision, "ACCEPT")

    def test_wrong_state_is_rejected(self):
        packet = self.registry.issue("ALICE", "BOB", self.sec["ALICE"], self.sec["BOB"], "M", "X+")
        result = self.detector.verify(packet, self.sec["BOB"], STATE_VECTORS["Z+"], shots=200, forced_attacker_label="Z+")
        self.assertEqual(result.decision, "REJECT")
        self.assertIn(result.threat_type, {"FORGERY", "FORGERY_OR_CHANNEL_MANIPULATION"})

    def test_replay_is_rejected(self):
        packet = self.registry.issue("ALICE", "BOB", self.sec["ALICE"], self.sec["BOB"], "M", "Z-")
        bob = recover_bob_state(packet, rng=self.rng)
        first = self.detector.verify(packet, self.sec["BOB"], bob, shots=100)
        second = self.detector.verify(packet, self.sec["BOB"], bob, shots=100, consume_session=False)
        self.assertEqual(first.decision, "ACCEPT")
        self.assertEqual(second.threat_type, "REPLAY")

    def test_impersonation_is_rejected(self):
        packet = self.registry.issue("ALICE", "BOB", self.sec["ALICE"], self.sec["BOB"], "M", "Y-")
        bob = recover_bob_state(packet, rng=self.rng)
        result = self.detector.verify(packet, "not-bob", bob, shots=100, consume_session=False)
        self.assertEqual(result.threat_type, "IMPERSONATION")


if __name__ == "__main__":
    unittest.main()
