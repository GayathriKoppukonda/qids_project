# Software Solution Architecture

## Stack
- Frontend: React 19 + Vite
- Backend API: FastAPI + Uvicorn
- Quantum engine: Python + NumPy state-vector simulator
- Persistence for prototype: in-memory registry; production version should use PostgreSQL/Redis or another durable store

## Run backend
From project root:

```bash
pip install -r requirements.txt
pip install -r backend/requirements.txt
uvicorn backend.main:app --reload
```

API docs: http://127.0.0.1:8000/docs

## Run frontend
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL shown in the terminal (typically http://localhost:5173).

## API endpoints
- GET /api/health
- GET /api/states
- POST /api/signatures
- POST /api/verify

## Architecture
React UI -> FastAPI -> protocol/authentication -> quantum simulation -> projective statistics -> deterministic threat rules -> JSON result -> dashboard.
