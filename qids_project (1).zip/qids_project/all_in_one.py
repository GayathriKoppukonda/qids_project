"""Single-file student demo.
Run: python all_in_one.py
Dependencies: numpy
"""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from math import sqrt
import hashlib, secrets, json
import numpy as np

I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.array([[1,0],[0,-1]],complex)
H=1/np.sqrt(2)*np.array([[1,1],[1,-1]],complex)
S=1/np.sqrt(2)
STATES={
 'Z+':np.array([1,0],complex),'Z-':np.array([0,1],complex),
 'X+':S*np.array([1,1],complex),'X-':S*np.array([1,-1],complex),
 'Y+':S*np.array([1,1j],complex),'Y-':S*np.array([1,-1j],complex)}

def norm(v): return v/np.linalg.norm(v)
def bell(): return S*np.array([1,0,0,1],complex)
def single(state, gate, q):
    mats=[gate if i==q else I for i in range(3)]
    full=mats[0]
    for m in mats[1:]: full=np.kron(full,m)
    return full@state
def cnot(state, c, t):
    out=np.zeros_like(state)
    for idx,a in enumerate(state):
        b=[(idx>>(2-q))&1 for q in range(3)]
        if b[c]: b[t]^=1
        j=(b[0]<<2)|(b[1]<<1)|b[2]
        out[j]+=a
    return out

def teleport(label,rng):
    st=np.kron(STATES[label],bell())
    st=cnot(st,0,1); st=single(st,H,0)
    a=st.reshape(2,2,2); p=np.abs(a)**2; pp=p.sum(axis=2).ravel(); o=int(rng.choice(4,p=pp/pp.sum()))
    m1,m2=divmod(o,2); bob=norm(a[m1,m2,:])
    if m2: bob=X@bob
    if m1: bob=Z@bob
    return norm(bob),(m1,m2)

def p_accept(state,label):
    v=STATES[label]; return float(np.clip(abs(np.vdot(v,norm(state)))**2,0,1))

@dataclass
class Packet:
    session_id:str; signer_id:str; verifier_id:str; message:str; state_label:str; digest:str; verifier_token_hash:str

class Registry:
    def __init__(self):
        self.signers={'ALICE':hashlib.sha256(b'alice-demo-token').hexdigest()}
        self.verifiers={'BOB':hashlib.sha256(b'bob-demo-token').hexdigest()}
        self.used=set()
    def issue(self,message,state):
        sid=secrets.token_hex(8); raw=f'{sid}|ALICE|BOB|{message}|{state}'
        return Packet(sid,'ALICE','BOB',message,state,hashlib.sha256(raw.encode()).hexdigest(),self.verifiers['BOB'])
    @staticmethod
    def h(token): return hashlib.sha256(token.encode()).hexdigest()

class Detector:
    def __init__(self,registry,threshold=.90,min_shots=30,z=3.0): self.r=registry; self.T=threshold; self.N=min_shots; self.z=z
    def verify(self,pkt,token,state,shots=200):
        if pkt.session_id in self.r.used: return {'decision':'REJECT','threat':'REPLAY'}
        if self.r.h(token)!=pkt.verifier_token_hash: return {'decision':'REJECT','threat':'IMPERSONATION'}
        if shots<self.N: return {'decision':'REJECT','threat':'INSUFFICIENT_SAMPLES'}
        p=p_accept(state,pkt.state_label); k=np.random.default_rng(7).binomial(shots,p); rate=k/shots; lb=rate-self.z*sqrt(max(rate*(1-rate)/shots,0))
        self.r.used.add(pkt.session_id)
        return {'decision':'ACCEPT' if lb>=self.T else 'REJECT','threat':'NONE' if lb>=self.T else 'FORGERY_OR_CHANNEL_MANIPULATION','p_expected':p,'success_rate':rate,'lower_bound':max(0,lb)}

if __name__=='__main__':
    rng=np.random.default_rng(42); reg=Registry(); det=Detector(reg); pkt=reg.issue('PAYMENT-001','X+'); bob,bits=teleport('X+',rng)
    print('Bell/teleportation bits:',bits)
    print(json.dumps(asdict(pkt),indent=2))
    print(json.dumps(det.verify(pkt,'bob-demo-token',bob),indent=2))
