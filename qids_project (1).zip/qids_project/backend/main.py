from __future__ import annotations

from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from src.protocol import SignatureRegistry
from src.detector import ThreatDetector
from src.quantum import STATE_VECTORS, teleport_once

app = FastAPI(title="Quantum-Inspired QDS Threat Detection API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

registry = SignatureRegistry()
registry.register_signer("alice", "alice-secret")
registry.register_verifier("bob", "bob-secret")
detector = ThreatDetector(registry, threshold=0.90, min_shots=30, z_value=3.0)

class IssueRequest(BaseModel):
    signer_id: str = "alice"
    verifier_id: str = "bob"
    signer_token: str = "alice-secret"
    verifier_token: str = "bob-secret"
    message: str = Field(min_length=1, max_length=1000)
    state_label: str = Field(default="X+", pattern=r"^(Z\+|Z-|X\+|X-|Y\+|Y-)$")

class VerifyRequest(BaseModel):
    packet: dict
    verifier_token: str = "bob-secret"
    actual_state_label: Optional[str] = None
    shots: int = Field(default=100, ge=30, le=100000)
    consume_session: bool = True

@app.get("/")
def root():
    return {"service": "QDS Threat Detection API", "status": "running"}

@app.get("/api/health")
def health():
    return {"status": "ok", "authorized_verifiers": sorted(registry.authorized_verifiers)}

@app.get("/api/states")
def states():
    return {"states": sorted(STATE_VECTORS.keys())}

@app.post("/api/signatures")
def issue_signature(req: IssueRequest):
    try:
        packet = registry.issue(
            req.signer_id, req.verifier_id, req.signer_token,
            req.verifier_token, req.message, req.state_label
        )
        return packet.to_dict()
    except (PermissionError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.post("/api/verify")
def verify_signature(req: VerifyRequest):
    try:
        from src.protocol import SignaturePacket
        packet = SignaturePacket(**req.packet)
        actual_label = req.actual_state_label or packet.state_label
        actual_state = teleport_once(actual_label).corrected_state
        result = detector.verify(
            packet,
            req.verifier_token,
            actual_state,
            shots=req.shots,
            consume_session=req.consume_session,
            forced_attacker_label=actual_label if actual_label != packet.state_label else None,
        )
        return result.to_dict()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
