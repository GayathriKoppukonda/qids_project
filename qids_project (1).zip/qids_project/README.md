# Quantum-Inspired Cyber Threat Detection for Digital Signature Security

Student reference implementation for **Egreen Quanta**.

This project is a **simulation/academic prototype** of a teleportation-based Quantum Digital Signature (QDS) threat-detection workflow. It is intentionally non-AI/non-ML: all decisions come from quantum-state simulation, projective measurement statistics, nonces, signer authorization, replay checks, and fixed thresholds.

## Features
- Bell-pair generation and quantum teleportation simulation.
- Pauli X/Y/Z corrections driven by Bell-measurement bits.
- Six Pauli eigenstates: Z+/Z-, X+/X-, Y+/Y-.
- Projective measurement and repeated verification shots.
- Fixed-threshold forgery/anomaly detector.
- Replay-attack detection using single-use session IDs.
- Signer impersonation and unauthorized-verifier checks.
- Deterministic JSON audit records.
- Attack simulation and regression tests.

## Important scope note
This is a **quantum-inspired research/demo framework**, not a production QDS implementation or a proof of information-theoretic security of a deployed protocol. Real QDS security depends on the exact protocol, device assumptions, noise model, authentication layer, randomness sources, and a formal security proof.

## Quick start

### 1. Create a virtual environment

Windows PowerShell:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the demonstration
```bash
python -m src.main demo
```

### 4. Run attack simulations
```bash
python -m src.main attacks
```

### 5. Run tests
```bash
python -m unittest discover -s tests -v
```

## Example commands
```bash
python -m src.main issue --signer ALICE --verifier BOB --state X+
python -m src.main verify --session SESSION_ID --shots 100
python -m src.main attacks
```

The easiest way to understand the system is to start with `python -m src.main demo`.
