from __future__ import annotations

import argparse
import json
from pprint import pprint
import numpy as np

from .attacks import make_registry, run_attack_suite
from .detector import ThreatDetector
from .protocol import recover_bob_state
from .quantum import STATE_VECTORS, projective_success_probability


def cmd_demo() -> None:
    registry, sec = make_registry()
    detector = ThreatDetector(registry, threshold=0.90, min_shots=30, z_value=3.0)
    rng = np.random.default_rng(42)
    packet = registry.issue("ALICE", "BOB", sec["ALICE"], sec["BOB"], "BLOCK:PAYMENT-001", "X+")
    bob = recover_bob_state(packet, rng=rng)
    result = detector.verify(packet, sec["BOB"], bob, shots=200)
    print("=== Quantum-Inspired QDS Threat Detection Demo ===")
    print(json.dumps(packet.to_dict(), indent=2))
    print(json.dumps(result.to_dict(), indent=2))


def cmd_issue(args) -> None:
    registry, sec = make_registry()
    packet = registry.issue(args.signer, args.verifier, sec[args.signer], sec[args.verifier], args.message, args.state)
    print(json.dumps(packet.to_dict(), indent=2))


def cmd_attacks() -> None:
    for item in run_attack_suite(shots=200):
        r = item["result"]
        print(f"{item['case']:20} -> {r['decision']:6} | {r['threat_type']:32} | rate={r['success_rate']:.3f} lower={r['lower_bound_approx']:.3f}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Quantum-inspired QDS cyber threat detection")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("demo", help="run the end-to-end demo")
    sub.add_parser("attacks", help="run the built-in attack suite")

    issue = sub.add_parser("issue", help="issue a simulated signature packet")
    issue.add_argument("--signer", default="ALICE", choices=["ALICE"])
    issue.add_argument("--verifier", default="BOB", choices=["BOB"])
    issue.add_argument("--message", default="HELLO-QUANTUM")
    issue.add_argument("--state", default="X+", choices=sorted(STATE_VECTORS))

    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.command == "demo":
        cmd_demo()
    elif args.command == "attacks":
        cmd_attacks()
    elif args.command == "issue":
        cmd_issue(args)


if __name__ == "__main__":
    main()
