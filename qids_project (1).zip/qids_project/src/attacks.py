from __future__ import annotations

from dataclasses import dataclass
import numpy as np

from .detector import ThreatDetector
from .protocol import SignatureRegistry, recover_bob_state
from .quantum import STATE_VECTORS, normalize


@dataclass
class AttackCase:
    name: str
    description: str
    expected_detection: str


def make_registry() -> tuple[SignatureRegistry, dict]:
    registry = SignatureRegistry()
    secrets_map = {
        "ALICE": "alice-demo-token",
        "BOB": "bob-demo-token",
        "EVE": "eve-invalid-token",
    }
    registry.register_signer("ALICE", secrets_map["ALICE"])
    registry.register_verifier("BOB", secrets_map["BOB"])
    return registry, secrets_map


def run_attack_suite(shots: int = 200) -> list[dict]:
    registry, sec = make_registry()
    detector = ThreatDetector(registry, threshold=0.90, min_shots=30, z_value=3.0)
    rng = np.random.default_rng(7)
    results = []

    # 1) Legitimate transaction.
    packet = registry.issue("ALICE", "BOB", sec["ALICE"], sec["BOB"], "PAY 100", "X+")
    state = recover_bob_state(packet, rng=rng)
    results.append({"case": "LEGITIMATE", "result": detector.verify(packet, sec["BOB"], state, shots=shots).to_dict()})

    # 2) Forgery: reuse the packet but present a different quantum state.
    packet2 = registry.issue("ALICE", "BOB", sec["ALICE"], sec["BOB"], "PAY 100", "X+")
    forged_state = STATE_VECTORS["Z+"]
    results.append({"case": "FORGERY", "result": detector.verify(packet2, sec["BOB"], forged_state, shots=shots, forced_attacker_label="Z+").to_dict()})

    # 3) Impersonation: wrong verifier token.
    packet3 = registry.issue("ALICE", "BOB", sec["ALICE"], sec["BOB"], "PAY 100", "Y-")
    state3 = recover_bob_state(packet3, rng=rng)
    results.append({"case": "IMPERSONATION", "result": detector.verify(packet3, "eve-wrong-token", state3, shots=shots, consume_session=False).to_dict()})

    # 4) Replay: same packet is verified twice.
    packet4 = registry.issue("ALICE", "BOB", sec["ALICE"], sec["BOB"], "PAY 100", "Z+")
    state4 = recover_bob_state(packet4, rng=rng)
    first = detector.verify(packet4, sec["BOB"], state4, shots=shots)
    second = detector.verify(packet4, sec["BOB"], state4, shots=shots, consume_session=False)
    results.append({"case": "REPLAY_FIRST", "result": first.to_dict()})
    results.append({"case": "REPLAY_SECOND", "result": second.to_dict()})

    # 5) Channel manipulation: perturb the state with a bit-flip-like mixture.
    packet5 = registry.issue("ALICE", "BOB", sec["ALICE"], sec["BOB"], "PAY 100", "X-")
    ideal = STATE_VECTORS["X-"]
    manipulated = normalize(0.70 * ideal + 0.714142842 * STATE_VECTORS["X+"])  # deliberately noisy
    results.append({"case": "CHANNEL_MANIPULATION", "result": detector.verify(packet5, sec["BOB"], manipulated, shots=shots).to_dict()})

    return results
