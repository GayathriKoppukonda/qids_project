"""Quantum-inspired digital-signature threat-detection demo package."""
