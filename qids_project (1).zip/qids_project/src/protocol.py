from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib
import secrets
from typing import Dict, Set

from .quantum import STATE_VECTORS, teleport_once


@dataclass
class SignaturePacket:
    session_id: str
    signer_id: str
    verifier_id: str
    message: str
    state_label: str
    digest: str
    issued_at: str
    valid_until: str
    verifier_token_hash: str

    def to_dict(self) -> dict:
        return asdict(self)


class SignatureRegistry:
    """Small in-memory registry representing an authenticated control plane."""

    def __init__(self) -> None:
        self.signer_tokens: Dict[str, str] = {}
        self.verifier_tokens: Dict[str, str] = {}
        self.used_sessions: Set[str] = set()
        self.authorized_verifiers: Set[str] = set()

    def register_signer(self, signer_id: str, token: str) -> None:
        self.signer_tokens[signer_id] = hashlib.sha256(token.encode()).hexdigest()

    def register_verifier(self, verifier_id: str, token: str) -> None:
        self.verifier_tokens[verifier_id] = hashlib.sha256(token.encode()).hexdigest()
        self.authorized_verifiers.add(verifier_id)

    def token_hash(self, token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()

    def issue(self, signer_id: str, verifier_id: str, signer_token: str, verifier_token: str, message: str, state_label: str, ttl_seconds: int = 300) -> SignaturePacket:
        if signer_id not in self.signer_tokens or self.token_hash(signer_token) != self.signer_tokens[signer_id]:
            raise PermissionError("Signer authentication failed")
        if verifier_id not in self.verifier_tokens or self.token_hash(verifier_token) != self.verifier_tokens[verifier_id]:
            raise PermissionError("Verifier authentication failed")
        if state_label not in STATE_VECTORS:
            raise ValueError("Unsupported Pauli eigenstate")
        now = datetime.now(timezone.utc)
        session_id = secrets.token_hex(12)
        canonical = f"{session_id}|{signer_id}|{verifier_id}|{message}|{state_label}"
        digest = hashlib.sha256(canonical.encode()).hexdigest()
        return SignaturePacket(
            session_id=session_id,
            signer_id=signer_id,
            verifier_id=verifier_id,
            message=message,
            state_label=state_label,
            digest=digest,
            issued_at=now.isoformat(),
            valid_until=(now.timestamp() + ttl_seconds).__str__(),
            verifier_token_hash=self.verifier_tokens[verifier_id],
        )

    def mark_used(self, session_id: str) -> None:
        self.used_sessions.add(session_id)

    def is_replay(self, session_id: str) -> bool:
        return session_id in self.used_sessions


def recover_bob_state(packet: SignaturePacket, rng=None):
    return teleport_once(packet.state_label, rng=rng).corrected_state
