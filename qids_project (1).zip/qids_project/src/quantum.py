from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple
import numpy as np

SQRT2_INV = 1 / np.sqrt(2.0)

# Single-qubit gates.
I = np.array([[1, 0], [0, 1]], dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)
H = SQRT2_INV * np.array([[1, 1], [1, -1]], dtype=complex)

STATE_VECTORS: Dict[str, np.ndarray] = {
    "Z+": np.array([1, 0], dtype=complex),
    "Z-": np.array([0, 1], dtype=complex),
    "X+": SQRT2_INV * np.array([1, 1], dtype=complex),
    "X-": SQRT2_INV * np.array([1, -1], dtype=complex),
    "Y+": SQRT2_INV * np.array([1, 1j], dtype=complex),
    "Y-": SQRT2_INV * np.array([1, -1j], dtype=complex),
}

# For verification, each public state label selects its Pauli eigenbasis.
BASIS_FOR_STATE = {
    "Z+": "Z", "Z-": "Z",
    "X+": "X", "X-": "X",
    "Y+": "Y", "Y-": "Y",
}

@dataclass(frozen=True)
class TeleportationResult:
    input_state: str
    bell_bits: Tuple[int, int]
    corrected_state: np.ndarray


def normalize(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    if n == 0:
        raise ValueError("Cannot normalize the zero vector")
    return v / n


def kron(*vectors_or_matrices: np.ndarray) -> np.ndarray:
    out = np.array([1], dtype=complex)
    for item in vectors_or_matrices:
        out = np.kron(out, item)
    return out


def bell_pair() -> np.ndarray:
    """Return |Phi+> = (|00> + |11>)/sqrt(2)."""
    return SQRT2_INV * np.array([1, 0, 0, 1], dtype=complex)


def tensor_state(message: np.ndarray, pair: np.ndarray) -> np.ndarray:
    return normalize(np.kron(message, pair))


def apply_single_qubit_gate(state: np.ndarray, gate: np.ndarray, qubit: int, n_qubits: int = 3) -> np.ndarray:
    """Apply a 2x2 gate to qubit index 0..n-1 using MSB-first ordering."""
    mats = [I] * n_qubits
    mats[qubit] = gate
    full = mats[0]
    for m in mats[1:]:
        full = np.kron(full, m)
    return full @ state


def apply_cnot(state: np.ndarray, control: int, target: int, n_qubits: int = 3) -> np.ndarray:
    """Apply CNOT by explicit basis-index transformation."""
    out = np.zeros_like(state)
    for idx, amp in enumerate(state):
        bits = [(idx >> (n_qubits - 1 - q)) & 1 for q in range(n_qubits)]
        if bits[control] == 1:
            bits[target] ^= 1
        new_idx = 0
        for b in bits:
            new_idx = (new_idx << 1) | b
        out[new_idx] += amp
    return out


def teleport_once(input_label: str, rng: np.random.Generator | None = None) -> TeleportationResult:
    """Simulate one teleportation run and return Bob's corrected qubit.

    The teleportation measurement is sampled from the exact state vector.
    After the classical correction, Bob's state equals the input state up to
    floating-point error.
    """
    if input_label not in STATE_VECTORS:
        raise ValueError(f"Unknown state label: {input_label}")
    rng = rng or np.random.default_rng()
    psi = STATE_VECTORS[input_label]
    state = tensor_state(psi, bell_pair())

    # Standard teleportation circuit on qubits [message, Alice, Bob].
    state = apply_cnot(state, 0, 1)
    state = apply_single_qubit_gate(state, H, 0)

    # Measure qubits 0 and 1 jointly. Probability by computational basis.
    probs = np.abs(state.reshape(2, 2, 2)) ** 2
    pair_probs = probs.sum(axis=2).reshape(-1)
    outcome = int(rng.choice(4, p=pair_probs / pair_probs.sum()))
    m1, m2 = divmod(outcome, 2)

    collapsed = state.reshape(2, 2, 2)[m1, m2, :]
    bob_state = normalize(collapsed)

    # Bob correction X^m2 Z^m1.
    if m2:
        bob_state = X @ bob_state
    if m1:
        bob_state = Z @ bob_state
    bob_state = normalize(bob_state)

    return TeleportationResult(input_label, (m1, m2), bob_state)


def projector_for_state(label: str) -> np.ndarray:
    if label not in STATE_VECTORS:
        raise ValueError(f"Unknown state label: {label}")
    psi = STATE_VECTORS[label]
    return np.outer(psi, psi.conjugate())


def projective_success_probability(actual_state: np.ndarray, expected_label: str) -> float:
    """Pr[expected projector clicks] = <psi|rho|psi> for a pure state."""
    actual_state = normalize(actual_state)
    projector = projector_for_state(expected_label)
    p = np.vdot(actual_state, projector @ actual_state).real
    return float(np.clip(p, 0.0, 1.0))


def measure_expected_state(actual_state: np.ndarray, expected_label: str, shots: int, rng: np.random.Generator | None = None) -> tuple[int, int, float]:
    if shots <= 0:
        raise ValueError("shots must be positive")
    rng = rng or np.random.default_rng()
    p = projective_success_probability(actual_state, expected_label)
    successes = int(rng.binomial(shots, p))
    failures = shots - successes
    return successes, failures, successes / shots
