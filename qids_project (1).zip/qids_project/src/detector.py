from __future__ import annotations

from dataclasses import dataclass, asdict
from math import sqrt
from datetime import datetime, timezone

from .quantum import measure_expected_state, projective_success_probability
from .protocol import SignaturePacket, SignatureRegistry


@dataclass
class VerificationResult:
    decision: str
    threat_type: str
    reason: str
    success_count: int
    failure_count: int
    success_rate: float
    expected_probability: float
    threshold: float
    lower_bound_approx: float
    session_id: str
    verifier_id: str
    timestamp: str

    def to_dict(self) -> dict:
        return asdict(self)


class ThreatDetector:
    def __init__(self, registry: SignatureRegistry, threshold: float = 0.90, min_shots: int = 30, z_value: float = 3.0) -> None:
        if not 0.0 < threshold <= 1.0:
            raise ValueError("threshold must be in (0, 1]")
        self.registry = registry
        self.threshold = threshold
        self.min_shots = min_shots
        self.z_value = z_value

    def _lower_bound(self, successes: int, shots: int) -> float:
        if shots <= 0:
            return 0.0
        p = successes / shots
        # Conservative normal approximation. The threshold is intentionally
        # fixed, deterministic, and NOT learned from data.
        se = sqrt(max(p * (1 - p) / shots, 0.0))
        return max(0.0, p - self.z_value * se)

    def verify(self, packet: SignaturePacket, presented_verifier_token: str, actual_state, shots: int = 100, consume_session: bool = True, forced_attacker_label: str | None = None) -> VerificationResult:
        now = datetime.now(timezone.utc).isoformat()

        if packet.verifier_id not in self.registry.authorized_verifiers:
            return VerificationResult("REJECT", "UNAUTHORIZED_VERIFIER", "Verifier is not authorized.", 0, 0, 0.0, 0.0, self.threshold, 0.0, packet.session_id, packet.verifier_id, now)
        if self.registry.token_hash(presented_verifier_token) != packet.verifier_token_hash:
            return VerificationResult("REJECT", "IMPERSONATION", "Verifier credential hash does not match the signed packet.", 0, 0, 0.0, 0.0, self.threshold, 0.0, packet.session_id, packet.verifier_id, now)
        if self.registry.is_replay(packet.session_id):
            return VerificationResult("REJECT", "REPLAY", "Session ID has already been consumed.", 0, 0, 0.0, 0.0, self.threshold, 0.0, packet.session_id, packet.verifier_id, now)
        if shots < self.min_shots:
            return VerificationResult("REJECT", "INSUFFICIENT_SAMPLES", f"At least {self.min_shots} projective measurements are required.", 0, 0, 0.0, 0.0, self.threshold, 0.0, packet.session_id, packet.verifier_id, now)

        successes, failures, success_rate = measure_expected_state(actual_state, packet.state_label, shots)
        expected_probability = projective_success_probability(actual_state, packet.state_label)
        lower = self._lower_bound(successes, shots)

        if forced_attacker_label and forced_attacker_label != packet.state_label:
            threat = "FORGERY"
        else:
            threat = "NONE"

        if lower >= self.threshold:
            decision = "ACCEPT"
            reason = "Observed projective-measurement agreement exceeds the fixed security threshold."
            threat_type = threat
        else:
            decision = "REJECT"
            threat_type = threat if threat != "NONE" else "FORGERY_OR_CHANNEL_MANIPULATION"
            reason = "Statistical evidence is below the fixed acceptance threshold."

        if consume_session:
            self.registry.mark_used(packet.session_id)

        return VerificationResult(decision, threat_type, reason, successes, failures, success_rate, expected_probability, self.threshold, lower, packet.session_id, packet.verifier_id, now)
