# Quantum-Inspired Cyber Threat Detection for Digital Signature Security

## Organization
**Egreen Quanta**  
**Department:** Egreen Quanta  
**Category:** Software  
**Theme:** Blockchain & Cybersecurity

## 1. Executive Summary

This project proposes a non-AI, quantum-inspired cyber threat detection framework for teleportation-based Quantum Digital Signature (QDS) systems. The reference implementation models Bell-state entanglement, quantum teleportation, Pauli correction, and projective measurements. A deterministic statistical decision layer then identifies signature forgery, impersonation, replay, unauthorized verification, and quantum-channel manipulation.

The prototype is deliberately designed as a research and demonstration simulator. It does not claim to implement a production QDS protocol or to prove information-theoretic security by itself. Instead, it provides a concrete software architecture that can be extended with a formally specified QDS protocol, calibrated device noise, authenticated classical channels, and formal security bounds.

## 2. Problem

Classical public-key cryptography faces a long-term quantum risk because sufficiently capable quantum computers could undermine some current public-key constructions. NIST describes the need to migrate toward quantum-resistant cryptographic mechanisms and notes that quantum computing creates risks for widely used public-key cryptosystems. [1][2]

A QDS system instead uses quantum states and measurements as part of signature generation and verification. The challenge addressed here is cyber-threat detection around the QDS process: not only deciding whether a signature is valid, but identifying evidence of forgery, impersonation, replay, and channel tampering without machine learning.

## 3. Objectives

1. Model a teleportation-based signature-verification workflow.
2. Use Bell-state entanglement and teleportation to move the signed qubit state.
3. Represent public signature states with Pauli eigenstates.
4. Verify using projective measurements and repeated samples.
5. Detect attacks using fixed statistical thresholds and protocol metadata.
6. Record auditable, deterministic decisions.
7. Keep the simulator lightweight enough for a student laptop and VS Code.

## 4. Proposed Solution

The system has five logical layers:

### Layer A — Quantum State Layer

Six Pauli eigenstates are supported:

- Z+ and Z−
- X+ and X−
- Y+ and Y−

For an expected state |psi>, the verification projector is:

P = |psi><psi|

For an observed pure qubit state |phi>, the ideal acceptance probability is:

p_accept = <phi|P|phi> = |<psi|phi>|²

Thus, a perfect legitimate transmission has p_accept = 1, while a different state can have a substantially lower overlap.

### Layer B — Teleportation Layer

The simulator creates the Bell state:

|Phi+> = (|00> + |11>)/sqrt(2)

The message qubit and Bell pair pass through the standard teleportation operations. Alice's two measurement bits determine Bob's Pauli correction. In the ideal noiseless model, Bob recovers the original state up to floating-point precision.

### Layer C — Signature Packet Layer

Each signature packet contains:

- one-time session ID / nonce;
- signer ID;
- verifier ID;
- message;
- Pauli eigenstate label;
- canonical SHA-256 digest;
- issue/expiry metadata;
- verifier credential hash.

The control-plane credential checks are classical and are used only to model authorization and identity binding; they do not replace the quantum security argument.

### Layer D — Measurement Statistics

The detector performs N projective measurements. If k outcomes match the expected projector, the observed agreement rate is:

r = k / N

For decision-making, the prototype uses a fixed threshold T and a conservative lower confidence approximation:

LB ≈ r − z * sqrt(r(1−r)/N)

The packet is accepted only if:

LB >= T

The default values are T = 0.90, z = 3.0, and N >= 30.

### Layer E — Cyber Threat Detection

The detector applies protocol rules before quantum statistics:

- unauthorized verifier -> reject;
- wrong verifier credential -> impersonation;
- reused session ID -> replay;
- insufficient measurement samples -> reject;
- low projective agreement -> forgery or channel manipulation.

No neural network, classifier, feature-learning step, training data, or adaptive ML threshold is used.

## 5. Attack Models

### 5.1 Forgery
An attacker presents a qubit state inconsistent with the packet's expected Pauli eigenstate. Example: packet declares X+ while the attacker supplies Z+.

For two orthogonal eigenstates the ideal overlap can be zero, making the projective test very effective in the noiseless model.

### 5.2 Impersonation
An attacker attempts to verify or act as another verifier without the expected credential hash. The detector rejects before measurement processing.

### 5.3 Replay
A previously consumed session ID is rejected on subsequent use. This is a classical freshness property layered around the quantum verification step.

### 5.4 Unauthorized verification
A verifier that is not registered in the authorization registry is rejected.

### 5.5 Channel manipulation
The prototype perturbs the expected qubit with a deliberately altered state. The projective measurement rate decreases and the threshold rule rejects when the statistical evidence becomes too weak.

## 6. Algorithms

### Algorithm 1 — Teleportation

1. Prepare message state |psi>.
2. Prepare Bell pair |Phi+>.
3. Apply CNOT(message, Alice-Bell).
4. Apply H(message).
5. Measure Alice's two qubits.
6. Apply X and Z corrections at Bob according to the two classical measurement bits.
7. Return Bob's corrected state.

### Algorithm 2 — Threat Detection

1. Validate verifier authorization.
2. Validate verifier credential hash.
3. Check session freshness.
4. Require a minimum number of measurements.
5. Run repeated projective measurements.
6. Compute success rate and conservative lower bound.
7. Accept only when the lower bound meets the fixed threshold.
8. Log the decision and threat class.

## 7. Software Architecture

```text
qids_project/
├── README.md
├── requirements.txt
├── src/
│   ├── __init__.py
│   ├── quantum.py       # states, Bell pair, teleportation, measurements
│   ├── protocol.py      # signature packet, registry, session freshness
│   ├── detector.py      # fixed-threshold statistical detector
│   ├── attacks.py       # forgery / replay / impersonation / channel attacks
│   └── main.py          # CLI entry point
├── tests/
│   └── test_project.py
├── data/
└── docs/
    └── project_report.md
```

## 8. Delivery Table (Expected Deliverables)

| Deliverable | Description | Status in reference project |
|---|---|---|
| Problem analysis | Threats, assumptions, goals | Included in this report |
| Quantum model | Bell pair, Pauli eigenstates, teleportation | `src/quantum.py` |
| Signature model | Session ID, signer/verifier identity, digest | `src/protocol.py` |
| Threat detector | Fixed threshold + statistical lower bound | `src/detector.py` |
| Attack simulator | Forgery, replay, impersonation, channel manipulation | `src/attacks.py` |
| CLI demo | One-command end-to-end demonstration | `src/main.py` |
| Automated tests | Regression checks | `tests/test_project.py` |
| Documentation | Setup, equations, architecture, limitations | `README.md`, this report |
| Performance evaluation | Measurement shots and decision metrics | Extendable through attack suite |

## 9. Performance Metrics

The framework can report:

- verification success rate;
- empirical acceptance probability;
- statistical lower confidence bound;
- attack detection rate;
- false-rejection rate under the selected noise model;
- verification runtime per N shots;
- number of protocol checks executed before quantum measurement.

For a college evaluation, run the attack suite with N = 50, 100, 200, 500, and 1000 shots and record the acceptance/rejection rate. In the ideal legitimate case, the simulator should remain near a 100% measurement agreement rate because the teleportation stage is noiseless.

## 10. Expected Results

The built-in tests are designed to show:

- ideal teleportation reconstructs the chosen Pauli eigenstate;
- legitimate signatures are accepted;
- mismatched quantum states are rejected as forgery/channel anomalies;
- replayed sessions are rejected;
- wrong verifier credentials are rejected as impersonation.

The exact empirical measurement counts vary because projective measurements are sampled randomly, but the decision rule is deterministic for a given measurement record.

## 11. Security Discussion

The system's strongest feature is explainability: every rejection is tied to a concrete protocol condition or a measurable statistical deviation. This avoids the opacity and data-dependence of an ML detector.

However, the simulator alone cannot establish information-theoretic security for a real-world QDS protocol. Formal QDS security also depends on the protocol definition, adversarial capabilities, quantum-channel assumptions, device trust, classical-channel authentication, randomness quality, finite-size effects, and implementation security.

NIST's post-quantum guidance emphasizes that quantum computing can threaten current public-key cryptography and that organizations should prepare migration strategies. [1][2]

## 12. Limitations

1. The implementation is an ideal state-vector simulator, not quantum hardware.
2. The lower confidence bound is an educational normal approximation, not a formal finite-key QDS security proof.
3. The credential layer is a simplified classical registry.
4. Noise is synthetic and not device-calibrated.
5. The code models the requested teleportation mechanism, but a deployable QDS protocol would need a complete formal protocol specification and security proof.

## 13. Future Scope

- Replace the hand-built simulator with a Qiskit/Cirq backend without changing detector APIs.
- Add density matrices and calibrated depolarizing / dephasing channels.
- Implement exact binomial confidence intervals and finite-key security bounds.
- Add a web dashboard for live attack and verification plots.
- Add a blockchain audit connector for immutable event logging.
- Compare multiple QDS protocol variants under the same detector interface.
- Extend from in-memory sessions to a signed event ledger.

## 14. Conclusion

This project demonstrates that cyber-threat detection for QDS can be built as a transparent, rule-based system around quantum measurement statistics rather than AI/ML. Bell-state entanglement and teleportation provide the quantum workflow; Pauli eigenstates and projective measurements provide a mathematical verification signal; and fixed statistical thresholds plus classical freshness/authorization checks provide the cyber-threat detection layer.

## References

[1] NIST, “What Is Post-Quantum Cryptography?”, updated February 27, 2026.  
[2] NIST, “Post-Quantum Cryptography”, current project guidance, accessed September 7, 2026.  
[3] NIST IR 8105, “Report on Post-Quantum Cryptography”, April 2016.  
[4] Y.-K. Liu and D. Moody, “Post-Quantum Cryptography, and the Quantum Future of Cybersecurity,” Physical Review Applied 21, 040501 (2024).
