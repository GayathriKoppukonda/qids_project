import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const API = 'http://127.0.0.1:8000/api';

function App() {
  const [message, setMessage] = useState('Quantum signature demo');
  const [stateLabel, setStateLabel] = useState('X+');
  const [packet, setPacket] = useState(null);
  const [result, setResult] = useState(null);
  const [attack, setAttack] = useState('none');
  const [loading, setLoading] = useState(false);

  async function issue() {
    setLoading(true);
    setResult(null);
    const r = await fetch(`${API}/signatures`, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({message, state_label: stateLabel})
    });
    const data = await r.json();
    setPacket(data);
    setLoading(false);
  }

  async function verify() {
    if (!packet) return;
    setLoading(true);
    let actual = null;
    if (attack === 'forgery' || attack === 'channel') {
      actual = attack === 'forgery' ? (stateLabel === 'X+' ? 'Z+' : 'X+') : 'Y+';
    }
    if (attack === 'replay') {
      // First call consumes the packet, second call demonstrates replay.
      await fetch(`${API}/verify`, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({packet, verifier_token: 'bob-secret', shots: 100, consume_session: true})
      });
    }
    const r = await fetch(`${API}/verify`, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({packet, verifier_token: 'bob-secret', actual_state_label: actual, shots: 100, consume_session: true})
    });
    const data = await r.json();
    setResult(data);
    setLoading(false);
  }

  const accepted = result?.decision === 'ACCEPT';

  return (
    <div className="shell">
      <header>
        <div>
          <p className="eyebrow">EGREEN QUANTA</p>
          <h1>Quantum-Inspired QDS Threat Detection</h1>
          <p className="subtitle">Teleportation-based signature verification without AI/ML</p>
        </div>
        <div className="status">Backend API: <b>FastAPI</b></div>
      </header>

      <main>
        <section className="grid two">
          <div className="card">
            <h2>1. Create Signature</h2>
            <label>Message</label>
            <input value={message} onChange={e => setMessage(e.target.value)} />
            <label>Pauli eigenstate</label>
            <select value={stateLabel} onChange={e => setStateLabel(e.target.value)}>
              {['Z+','Z-','X+','X-','Y+','Y-'].map(s => <option key={s}>{s}</option>)}
            </select>
            <button onClick={issue} disabled={loading}>Issue QDS Packet</button>
          </div>

          <div className="card">
            <h2>2. Verify / Attack Simulation</h2>
            <label>Scenario</label>
            <select value={attack} onChange={e => setAttack(e.target.value)}>
              <option value="none">Legitimate</option>
              <option value="forgery">Forgery</option>
              <option value="replay">Replay</option>
              <option value="channel">Channel Manipulation</option>
            </select>
            <button onClick={verify} disabled={!packet || loading}>Run Verification</button>
            <p className="hint">Impersonation is exercised through the API by changing the verifier token.</p>
          </div>
        </section>

        <section className="grid two">
          <div className="card">
            <h2>Signature Packet</h2>
            <pre>{packet ? JSON.stringify(packet, null, 2) : 'No packet yet.'}</pre>
          </div>
          <div className="card">
            <h2>Detection Result</h2>
            {!result ? <div className="empty">Run a verification to see statistical evidence.</div> : (
              <>
                <div className={`decision ${accepted ? 'accept' : 'reject'}`}>{result.decision}</div>
                <div className="metricGrid">
                  <div><span>Threat</span><b>{result.threat_type}</b></div>
                  <div><span>Success rate</span><b>{result.success_rate.toFixed(3)}</b></div>
                  <div><span>Expected p</span><b>{result.expected_probability.toFixed(3)}</b></div>
                  <div><span>Lower bound</span><b>{result.lower_bound_approx.toFixed(3)}</b></div>
                  <div><span>Threshold</span><b>{result.threshold.toFixed(2)}</b></div>
                  <div><span>Samples</span><b>{result.success_count + result.failure_count}</b></div>
                </div>
                <p>{result.reason}</p>
              </>
            )}
          </div>
        </section>
      </main>

      <footer>Academic simulator: demonstrates the requested quantum-inspired detection workflow; not a production QDS deployment.</footer>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
